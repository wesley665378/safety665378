import React, { useState, useMemo } from 'react';
import { LawDocument } from '../types';

interface KnowledgeBaseProps {
  documents: LawDocument[];
  onAddDocument: (doc: LawDocument) => void;
  onDeleteDocument: (id: string) => void;
}

const KnowledgeBase: React.FC<KnowledgeBaseProps> = ({ documents, onAddDocument, onDeleteDocument }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<LawDocument['category']>('law');
  const [newContent, setNewContent] = useState('');
  
  // Filter state
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const handleSave = () => {
    if (!newTitle || !newContent) return;

    const newDoc: LawDocument = {
      id: Date.now().toString(),
      title: newTitle,
      category: newCategory,
      content: newContent,
      dateAdded: Date.now(),
    };

    onAddDocument(newDoc);
    setIsAdding(false);
    setNewTitle('');
    setNewContent('');
    setNewCategory('law');
  };

  const filteredDocuments = useMemo(() => {
    if (filterCategory === 'all') return documents;
    return documents.filter(doc => doc.category === filterCategory);
  }, [documents, filterCategory]);

  return (
    <div className="flex flex-col h-full bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-50">
        <div>
          <h2 className="text-lg font-bold text-slate-800">法律法规知识库</h2>
          <p className="text-sm text-slate-500">
            当前已学习 {documents.length} 份文档，支持实时检索与问答。
          </p>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm flex items-center gap-2"
        >
          {isAdding ? '取消添加' : '+ 添加新法规'}
        </button>
      </div>

      {!isAdding && (
        <div className="px-6 py-3 border-b border-slate-100 bg-white flex gap-2 overflow-x-auto scrollbar-hide">
           <button 
             onClick={() => setFilterCategory('all')}
             className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap ${filterCategory === 'all' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
           >
             全部 ({documents.length})
           </button>
           <button 
             onClick={() => setFilterCategory('law')}
             className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap ${filterCategory === 'law' ? 'bg-red-100 text-red-700 ring-1 ring-red-200' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}`}
           >
             法律 ({documents.filter(d => d.category === 'law').length})
           </button>
           <button 
             onClick={() => setFilterCategory('regulation')}
             className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap ${filterCategory === 'regulation' ? 'bg-orange-100 text-orange-700 ring-1 ring-orange-200' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}`}
           >
             行政法规 ({documents.filter(d => d.category === 'regulation').length})
           </button>
           <button 
             onClick={() => setFilterCategory('rule')}
             className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap ${filterCategory === 'rule' ? 'bg-blue-100 text-blue-700 ring-1 ring-blue-200' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}`}
           >
             部门规章 ({documents.filter(d => d.category === 'rule').length})
           </button>
           <button 
             onClick={() => setFilterCategory('local')}
             className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap ${filterCategory === 'local' ? 'bg-green-100 text-green-700 ring-1 ring-green-200' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}`}
           >
             地方性法规 ({documents.filter(d => d.category === 'local').length})
           </button>
        </div>
      )}

      <div className="flex-1 overflow-hidden flex">
        {isAdding ? (
          <div className="flex-1 p-6 overflow-y-auto bg-slate-50 animate-fade-in">
            <div className="max-w-3xl mx-auto bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-semibold text-lg text-slate-800 mb-4">录入新文件</h3>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">法规标题</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  placeholder="例如：中华人民共和国安全生产法"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">类别</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="law">法律</option>
                  <option value="regulation">行政法规</option>
                  <option value="rule">部门规章</option>
                  <option value="local">地方性法规</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">正文内容</label>
                <textarea
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full h-64 rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-mono"
                  placeholder="在此处粘贴法规全文..."
                />
              </div>

              <div className="pt-4 flex justify-end gap-3">
                <button
                  onClick={() => setIsAdding(false)}
                  className="px-4 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  取消
                </button>
                <button
                  onClick={handleSave}
                  disabled={!newTitle || !newContent}
                  className={`px-4 py-2 text-sm text-white rounded-lg transition-colors ${
                    !newTitle || !newContent ? 'bg-slate-300 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  保存到知识库
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 content-start">
            {filteredDocuments.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center h-64 text-slate-400">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mb-3">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                </svg>
                <p>该分类下暂无文档</p>
              </div>
            ) : (
              filteredDocuments.map((doc) => (
                <div key={doc.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group relative flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                      doc.category === 'law' ? 'bg-red-100 text-red-700' :
                      doc.category === 'regulation' ? 'bg-orange-100 text-orange-700' :
                      doc.category === 'rule' ? 'bg-blue-100 text-blue-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {doc.category === 'law' ? '法律' : doc.category === 'regulation' ? '行政法规' : doc.category === 'rule' ? '规章' : '地方性法规'}
                    </span>
                    <button
                      onClick={() => onDeleteDocument(doc.id)}
                      className="text-slate-300 hover:text-red-500 transition-colors"
                      title="删除文档"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                        <path fillRule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 013.878.512.75.75 0 11-.49 1.478l-.56 9.06a4.424 4.424 0 01-4.414 4.094H9.086a4.424 4.424 0 01-4.414-4.094l-.56-9.06a48.819 48.819 0 01-3.878-.512.75.75 0 11.49-1.478 48.831 48.831 0 013.878-.512V4.478a2.25 2.25 0 012.25-2.25h3.75a2.25 2.25 0 012.25 2.25zM12 9a.75.75 0 01.75.75v5.5a.75.75 0 01-1.5 0v-5.5A.75.75 0 0112 9z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                  <h3 className="font-bold text-slate-800 mb-2 line-clamp-2 min-h-[3rem]">{doc.title}</h3>
                  <div className="flex-1">
                    <p className="text-xs text-slate-500 line-clamp-4 mb-2">
                      {doc.content}
                    </p>
                  </div>
                  <div className="text-[10px] text-slate-400 pt-2 border-t border-slate-50 mt-auto">
                    ID: {doc.id}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default KnowledgeBase;