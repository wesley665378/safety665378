import React from 'react';
import { AppView } from '../types';

interface SidebarProps {
  currentView: AppView;
  onChangeView: (view: AppView) => void;
  docCount: number;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView, docCount }) => {
  const menuItems = [
    { id: AppView.CHAT, label: '智能咨询对话', icon: '💬' },
    { id: AppView.DATA_COLLECTION, label: '法律法规采集', icon: '📡' },
    { id: AppView.KNOWLEDGE_BASE, label: '法律知识库', icon: '📚', count: docCount },
    { id: AppView.COMPLIANCE_CHECK, label: '符合性检查', icon: '🛡️' },
    { id: AppView.PUBLISH_GUIDE, label: '发布与共享', icon: '🚀' },
    { id: AppView.BUILD_STEPS, label: '搭建步骤详解', icon: '🛠️' },
  ];

  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col h-full shadow-xl">
      <div className="p-6 border-b border-slate-700">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center font-bold text-lg">
            世
          </div>
          <h1 className="text-xl font-bold tracking-tight">世和助手</h1>
        </div>
        <p className="text-xs text-slate-400">安全应急法律体系智能体</p>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onChangeView(item.id)}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all duration-200 ${
              currentView === item.id
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <span>{item.icon}</span>
              <span className="font-medium">{item.label}</span>
            </div>
            {item.count !== undefined && (
              <span className="bg-slate-700 text-xs px-2 py-0.5 rounded-full text-slate-300">
                {item.count}
              </span>
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800 rounded p-3 text-xs text-slate-400">
          <p className="font-semibold text-slate-300 mb-1">系统状态</p>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            Gemini 模型在线
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;