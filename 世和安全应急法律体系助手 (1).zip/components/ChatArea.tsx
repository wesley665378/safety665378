import React, { useState, useRef, useEffect } from 'react';
import { Message, LawDocument } from '../types';
import { sendMessageToGemini } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';

interface ChatAreaProps {
  documents: LawDocument[];
}

const ChatArea: React.FC<ChatAreaProps> = ({ documents }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      content: '您好，我是世和安全应急法律体系助手。我已经学习了现行的安全生产、应急管理相关法律法规。\n\n请问有什么可以帮您？您可以询问具体的法律条文，或者咨询特定场景下的合规要求。',
      timestamp: Date.now(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await sendMessageToGemini(messages, input, documents);
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: responseText,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (error) {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: '抱歉，系统暂时遇到问题，请稍后再试。',
        timestamp: Date.now(),
        isError: true,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Watermark SVG
  const watermarkSvg = encodeURIComponent(`
    <svg width="300" height="300" xmlns="http://www.w3.org/2000/svg">
      <text 
        x="50%" 
        y="50%" 
        font-family="'Noto Sans SC', sans-serif" 
        font-size="20" 
        fill="#cbd5e1" 
        font-weight="bold"
        text-anchor="middle" 
        dominant-baseline="middle"
        transform="rotate(-45 150 150)"
      >
        世和安全
      </text>
    </svg>
  `.replace(/\s+/g, ' ').trim());

  return (
    <div className="flex flex-col h-full bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Chat Header */}
      <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
        <div>
          <h2 className="font-semibold text-slate-800">国家注册安全工程师对话</h2>
          <p className="text-xs text-slate-500">基于已录入的 {documents.length} 份法律文档回答</p>
        </div>
        <button 
          onClick={() => setMessages([messages[0]])}
          className="text-xs text-slate-500 hover:text-red-500 transition-colors"
        >
          清空对话
        </button>
      </div>

      {/* Messages List */}
      <div 
        className="flex-1 overflow-y-auto p-4 space-y-6 bg-slate-50/50 relative"
        style={{
          backgroundImage: `url("data:image/svg+xml,${watermarkSvg}")`,
          backgroundRepeat: 'repeat',
          backgroundPosition: 'center'
        }}
      >
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} relative z-10`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-5 py-3.5 shadow-sm text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white rounded-tr-none'
                  : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none'
              } ${msg.isError ? 'bg-red-50 border-red-200 text-red-800' : ''}`}
            >
               {msg.role === 'model' ? (
                 <div className="prose prose-sm prose-slate max-w-none">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                 </div>
               ) : (
                 msg.content
               )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start relative z-10">
            <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-none px-5 py-4 shadow-sm flex items-center space-x-2">
              <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
              <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
              <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t border-slate-100 z-20">
        <div className="relative flex items-end gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="请输入您的问题，例如：企业主要负责人对安全生产工作负有什么职责？"
            className="w-full resize-none rounded-xl border border-slate-300 bg-slate-50 p-3 pr-12 text-sm text-slate-900 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 focus:outline-none max-h-32 min-h-[50px]"
            rows={2}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className={`absolute right-2 bottom-2 p-2 rounded-lg transition-all ${
              !input.trim() || isLoading
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-blue-600 text-white hover:bg-blue-700 shadow-sm'
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
            </svg>
          </button>
        </div>
        <p className="text-[10px] text-slate-400 text-center mt-2">
          AI回答仅供参考，不作为最终法律依据。具体案件请咨询专业律师。
        </p>
      </div>
    </div>
  );
};

export default ChatArea;