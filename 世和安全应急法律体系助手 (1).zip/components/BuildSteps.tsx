import React from 'react';

const BuildSteps: React.FC = () => {
  return (
    <div className="h-full overflow-y-auto bg-white rounded-xl shadow-sm border border-slate-200">
      <div className="p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-900 mb-6">“世和安全应急法律体系助手”智能体搭建步骤</h1>
        <p className="text-slate-600 mb-8 text-lg">
          构建一个企业级的法律合规问答系统需要经过严格的数据处理和模型工程。以下是完整的实施路径：
        </p>

        <div className="space-y-12">
          {/* Step 1 */}
          <section className="relative pl-8 border-l-2 border-blue-200">
            <span className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-blue-600 ring-4 ring-white"></span>
            <h2 className="text-xl font-bold text-slate-800 mb-3">步骤一：法律法规数据采集与清洗 (Data Collection)</h2>
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
              <ul className="list-disc ml-5 space-y-2 text-slate-700">
                <li><strong>源头锁定</strong>：确定数据源（如应急管理部官网、国家法律法规数据库、地方政府门户）。</li>
                <li><strong>爬虫/下载</strong>：使用Python (Scrapy/Selenium) 自动抓取安全生产法、突发事件应对法、消防法等全文。</li>
                <li><strong>数据清洗</strong>：去除HTML标签、广告水印、非正文内容。</li>
                <li><strong>元数据提取</strong>：结构化提取标题、发文机关、发布日期、效力级别（法律/法规/规章）。</li>
              </ul>
            </div>
          </section>

          {/* Step 2 */}
          <section className="relative pl-8 border-l-2 border-blue-200">
            <span className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-blue-600 ring-4 ring-white"></span>
            <h2 className="text-xl font-bold text-slate-800 mb-3">步骤二：构建向量知识库 (Knowledge Embedding)</h2>
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
              <ul className="list-disc ml-5 space-y-2 text-slate-700">
                <li><strong>文本切片 (Chunking)</strong>：由于法律条款独立性强，通常按“条”或“款”进行切分（例如：Chunk 1 = 《安全生产法》第一条...）。保留上下文（Overlap）以防止语义断裂。</li>
                <li><strong>向量化 (Embedding)</strong>：使用 Embedding 模型（如 text-embedding-004）将文本块转化为高维向量。</li>
                <li><strong>存入向量数据库</strong>：将向量和原始文本存入 Vector DB（如 Pinecone, Milvus, ChromaDB）。</li>
              </ul>
            </div>
          </section>

          {/* Step 3 */}
          <section className="relative pl-8 border-l-2 border-blue-200">
            <span className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-blue-600 ring-4 ring-white"></span>
            <h2 className="text-xl font-bold text-slate-800 mb-3">步骤三：构建检索增强生成系统 (RAG Architecture)</h2>
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
              <ul className="list-disc ml-5 space-y-2 text-slate-700">
                <li><strong>用户查询处理</strong>：将用户问题（如“企业发生事故怎么处罚？”）也转化为向量。</li>
                <li><strong>语义检索</strong>：在向量库中计算余弦相似度，找出最相关的Top-N条法律条款。</li>
                <li><strong>Prompt工程</strong>：构建提示词模版：
                  <code className="block bg-slate-800 text-green-400 p-2 my-2 text-xs rounded">
                    你是一名安全专家。请仅根据以下检索到的法律条款回答用户问题：<br/>
                    [检索到的条款内容]<br/>
                    用户问题：[用户输入]
                  </code>
                </li>
              </ul>
            </div>
          </section>

          {/* Step 4 */}
          <section className="relative pl-8 border-l-2 border-blue-200">
            <span className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-blue-600 ring-4 ring-white"></span>
            <h2 className="text-xl font-bold text-slate-800 mb-3">步骤四：前端交互与API集成 (Application Logic)</h2>
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
              <ul className="list-disc ml-5 space-y-2 text-slate-700">
                <li><strong>对话界面</strong>：React + Tailwind 开发类似ChatGPT的流式对话UI。</li>
                <li><strong>上下文管理</strong>：在Client端或Server端维护对话历史，实现多轮对话。</li>
                <li><strong>大模型调用</strong>：接入 Gemini Pro/Flash 或其他 LLM API 生成最终回复。</li>
              </ul>
            </div>
          </section>

          {/* Step 5 */}
          <section className="relative pl-8 border-l-2 border-blue-200">
            <span className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-blue-600 ring-4 ring-white"></span>
            <h2 className="text-xl font-bold text-slate-800 mb-3">步骤五：部署与持续优化 (Deployment & Optimization)</h2>
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
              <ul className="list-disc ml-5 space-y-2 text-slate-700">
                <li><strong>法规更新机制</strong>：建立定期任务监测应急管理部动态，自动更新知识库。</li>
                <li><strong>反馈循环</strong>：添加“点赞/点踩”功能，收集Bad Cases进行Prompt微调。</li>
                <li><strong>合规审查</strong>：确保模型输出不产生法律误导（Disclaimer）。</li>
              </ul>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default BuildSteps;