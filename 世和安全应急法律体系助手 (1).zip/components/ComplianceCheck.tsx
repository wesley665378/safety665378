import React from 'react';

const ComplianceCheck: React.FC = () => {
  return (
    <div className="flex flex-col h-full bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-6 border-b border-slate-100 bg-slate-50">
        <h2 className="text-lg font-bold text-slate-800">智能体符合性检查</h2>
        <p className="text-sm text-slate-500">
          监控法律类AI核心指标，确保输出内容的准确性、可解释性与合规性。
        </p>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-4xl mx-auto space-y-8">
          
          {/* Main Status Card */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-lg">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xl font-bold mb-2">系统合规护栏已激活</h3>
                <p className="text-blue-100 opacity-90 max-w-xl">
                  当前系统已强制开启法律条款引用验证机制。模型输出受到严格约束，优先依据《安全生产法》等现行有效法律法规。
                </p>
              </div>
              <div className="bg-white/10 backdrop-blur-md rounded-lg p-3 border border-white/20">
                <div className="text-xs text-blue-200 uppercase tracking-wider mb-1">Health Status</div>
                <div className="flex items-center gap-2 text-lg font-bold">
                   <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-green-400"></span>
                    </span>
                   Optimal
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Accuracy / Temperature */}
            <div className="border border-slate-200 rounded-xl p-6 hover:shadow-md transition-shadow relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50 rounded-full -mr-10 -mt-10 transition-transform group-hover:scale-110"></div>
               <div className="relative z-10">
                 <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mb-4 text-xl">
                   🎯
                 </div>
                 <h4 className="font-bold text-slate-800 text-lg mb-2">准确性控制 (Accuracy)</h4>
                 <p className="text-slate-600 text-sm mb-4">
                   为了减少法律问答中的“幻觉”风险，系统参数已进行针对性调优。
                 </p>
                 <div className="bg-slate-50 rounded-lg p-3 text-xs font-mono text-slate-600 border border-slate-100">
                   <div>Temperature: <span className="text-blue-600 font-bold">0.3</span> (Low)</div>
                   <div>Top_P: <span className="text-blue-600 font-bold">0.8</span></div>
                   <div className="mt-1 text-slate-400">// 低随机性确保事实性回答</div>
                 </div>
               </div>
            </div>

            {/* Source Citation */}
            <div className="border border-slate-200 rounded-xl p-6 hover:shadow-md transition-shadow relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-24 h-24 bg-green-50 rounded-full -mr-10 -mt-10 transition-transform group-hover:scale-110"></div>
               <div className="relative z-10">
                 <div className="w-10 h-10 bg-green-100 text-green-600 rounded-lg flex items-center justify-center mb-4 text-xl">
                   ⚖️
                 </div>
                 <h4 className="font-bold text-slate-800 text-lg mb-2">强制引用来源 (Citation)</h4>
                 <p className="text-slate-600 text-sm mb-4">
                   所有回答必须明确标注法律出处。系统提示词(Prompt)已包含强制引用指令。
                 </p>
                 <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-slate-600">
                       <svg className="w-4 h-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                       <span>引用法律位阶（法律/法规/规章）</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-600">
                       <svg className="w-4 h-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                       <span>标注具体条文号（如：第二十一条）</span>
                    </div>
                 </div>
               </div>
            </div>

            {/* Explainability */}
            <div className="border border-slate-200 rounded-xl p-6 hover:shadow-md transition-shadow relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-24 h-24 bg-purple-50 rounded-full -mr-10 -mt-10 transition-transform group-hover:scale-110"></div>
               <div className="relative z-10">
                 <div className="w-10 h-10 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center mb-4 text-xl">
                   🧠
                 </div>
                 <h4 className="font-bold text-slate-800 text-lg mb-2">可解释性 (Explainability)</h4>
                 <p className="text-slate-600 text-sm mb-4">
                   不仅提供结论，更提供推导过程。AI 被要求展示法律适用逻辑。
                 </p>
                 <div className="bg-slate-50 rounded-lg p-3 border border-slate-100">
                    <div className="flex items-center gap-2 mb-2">
                        <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-[10px] font-bold rounded">Chain of Thought</span>
                    </div>
                    <p className="text-xs text-slate-500 italic">
                       "首先判断企业类型 -> 其次查找对应法规 -> 最后确定具体责任条款"
                    </p>
                 </div>
               </div>
            </div>

            {/* Disclaimer */}
             <div className="border border-slate-200 rounded-xl p-6 hover:shadow-md transition-shadow relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-24 h-24 bg-orange-50 rounded-full -mr-10 -mt-10 transition-transform group-hover:scale-110"></div>
               <div className="relative z-10">
                 <div className="w-10 h-10 bg-orange-100 text-orange-600 rounded-lg flex items-center justify-center mb-4 text-xl">
                   ⚠️
                 </div>
                 <h4 className="font-bold text-slate-800 text-lg mb-2">免责声明注入 (Disclaimer)</h4>
                 <p className="text-slate-600 text-sm mb-4">
                   系统在UI层和模型输出层双重注入免责声明，明确AI辅助性质。
                 </p>
                 <div className="bg-orange-50 border border-orange-100 rounded p-2 text-[10px] text-orange-800">
                   系统预设文本：<br/>
                   “AI回答仅供参考，不作为最终法律依据。具体案件请咨询专业律师。”
                 </div>
               </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplianceCheck;