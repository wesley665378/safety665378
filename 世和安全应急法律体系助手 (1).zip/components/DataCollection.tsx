import React, { useState, useRef, useEffect } from 'react';
import { LawDocument } from '../types';

interface DataCollectionProps {
  onAddDocument: (doc: LawDocument) => void;
}

const DataCollection: React.FC<DataCollectionProps> = ({ onAddDocument }) => {
  const [isCollecting, setIsCollecting] = useState(false);
  const [activeSourceId, setActiveSourceId] = useState<string>('mem');
  const [logs, setLogs] = useState<string[]>([]);
  const [progress, setProgress] = useState(0);
  const [collectedDocs, setCollectedDocs] = useState<LawDocument[]>([]);
  const [isContinuous, setIsContinuous] = useState(false);
  const logsEndRef = useRef<HTMLDivElement>(null);

  const keywords = ['安全生产', '应急救援', '危险化学品', '粉尘防爆', '重大隐患'];

  const sources = [
    { 
      id: 'mem', 
      name: '中华人民共和国应急管理部', 
      url: 'https://www.mem.gov.cn/fw/flfg/',
      color: 'blue'
    },
    { 
      id: 'gd', 
      name: '广东省人民政府', 
      url: 'http://www.gd.gov.cn/zwgk/wjk/zfgz/',
      color: 'green' 
    },
    { 
      id: 'sz', 
      name: '深圳市人民政府', 
      url: 'http://www.sz.gov.cn/cn/xxgk/zfxxgj/zcfg/',
      color: 'indigo' 
    },
    { 
      id: 'npc', 
      name: '国家法律法规数据库', 
      url: 'https://flk.npc.gov.cn/',
      color: 'red' 
    },
  ];

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = (message: string) => {
    setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
  };

  const getMockDocument = (sourceId: string): LawDocument => {
    // Generate different documents based on random chance or source to simulate "Dust" learning
    if (sourceId === 'npc') {
      return {
        id: `auto-npc-${Date.now()}`,
        title: '中华人民共和国特种设备安全法',
        category: 'law',
        dateAdded: Date.now(),
        content: '第十三条 特种设备生产、经营、使用单位及其主要负责人对其生产、经营、使用的特种设备安全负责。特种设备生产、经营、使用单位应当按照国家有关规定配备特种设备安全管理人员、检测人员和作业人员，并对其进行必要的安全教育和技能培训。'
      };
    } else if (sourceId === 'gd') {
      return {
        id: `auto-gd-${Date.now()}`,
        title: '广东省安全生产责任保险实施办法', 
        category: 'local',
        dateAdded: Date.now(),
        content: '第三条 广东省行政区域内煤矿、非煤矿山、危险化学品、烟花爆竹、交通运输、建筑施工、民用爆炸物品、金属冶炼、渔业生产等高危行业领域的生产经营单位，应当投保安全生产责任保险。鼓励其他行业领域的生产经营单位投保安全生产责任保险。'
      };
    } else if (sourceId === 'sz') {
      return {
        id: `auto-sz-${Date.now()}`,
        title: '深圳经济特区危险化学品安全管理条例',
        category: 'local',
        dateAdded: Date.now(),
        content: '第八条 危险化学品生产、储存、使用、经营单位应当建立危险化学品安全管理制度，落实安全管理责任。禁止在专门区域外新建、扩建危险化学品生产、储存项目。'
      };
    } else {
       // MEM source might find dust regulations
       return {
        id: `auto-mem-dust-${Date.now()}`,
        title: '工贸企业粉尘防爆安全规定解读', 
        category: 'rule',
        dateAdded: Date.now(),
        content: '《规定》明确了粉尘涉爆企业对粉尘防爆工作负主体责任。企业应当辨识粉尘云、粉尘层爆炸安全风险，确定风险等级，建立风险分级管控清单。对于存在粉尘爆炸危险的场所，必须严格执行清扫制度。'
      };
    }
  };

  const startCollection = () => {
    if (isCollecting) return;
    
    const activeSource = sources.find(s => s.id === activeSourceId) || sources[0];
    
    setIsCollecting(true);
    setLogs([]);
    setProgress(0);
    setCollectedDocs([]);

    addLog(`初始化采集引擎 (Target: ${activeSource.name})...`);
    addLog(`模式: ${isContinuous ? '持续监测 (Continuous Learning)' : '单次采集'}`);
    addLog(`加载内容过滤器: [${keywords.join(', ')}]`);

    let step = 0;
    const interval = setInterval(() => {
      step++;
      setProgress(step * 5);

      if (step === 2) addLog(`正在解析 DNS: ${new URL(activeSource.url).hostname}...`);
      if (step === 4) addLog(`连接到服务器... 成功 (200 OK)`);
      if (step === 6) addLog(`正在遍历 ${activeSource.url} 目录...`);
      if (step === 8) addLog('正在扫描页面内容...');
      
      // Simulation of filtering
      if (step === 10) addLog('发现 15 条更新，正在进行关键词匹配...');
      if (step === 11) addLog(`>>> 过滤: "某某行政会议纪要" (无关键词) -> [忽略]`);
      if (step === 12) addLog(`>>> 过滤: "机关后勤管理规定" (无关键词) -> [忽略]`);
      
      const mockDoc = getMockDocument(activeSourceId);
      
      // Dynamic log based on mock content
      const matchedKeyword = keywords.find(k => mockDoc.title.includes(k) || mockDoc.content.includes(k)) || '安全生产';

      if (step === 14) addLog(`>>> 匹配: "${matchedKeyword}" -> 命中!`);
      if (step === 15) addLog(`发现目标文档: 《${mockDoc.title}》`);
      if (step === 17) addLog('正在下载 HTML/PDF 内容...');
      if (step === 19) addLog('正在进行 NLP 清洗与结构化存储...');
      
      if (step === 20) {
        clearInterval(interval);
        setIsCollecting(false);
        setProgress(100);
        addLog('采集任务完成。成功入库 1 篇高相关性文档。');
        
        onAddDocument(mockDoc);
        setCollectedDocs([mockDoc]);

        if (isContinuous) {
           addLog('>>> 进入待机模式。下次自动扫描时间：24小时后。');
        }
      }
    }, 250);
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-6 border-b border-slate-100 bg-slate-50">
        <h2 className="text-lg font-bold text-slate-800">法律法规智能采集</h2>
        <p className="text-sm text-slate-500">
          定向采集政府官网，利用NLP技术自动筛选高价值法律法规。支持“安全生产”、“危险化学品”、“粉尘防爆”等垂直领域持续学习。
        </p>
      </div>

      <div className="flex-1 p-6 overflow-y-auto space-y-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Source Configuration */}
            <div className="bg-white border border-slate-200 rounded-xl p-5">
            <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" />
                </svg>
                数据源选择
            </h3>
            <div className="space-y-2">
                {sources.map((source) => (
                <button
                    key={source.id}
                    onClick={() => !isCollecting && setActiveSourceId(source.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all text-left ${
                    activeSourceId === source.id 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-slate-100 bg-slate-50 hover:bg-slate-100'
                    } ${isCollecting ? 'cursor-not-allowed opacity-70' : 'cursor-pointer'}`}
                >
                    <div className="flex flex-col overflow-hidden">
                        <span className={`font-medium text-sm ${activeSourceId === source.id ? 'text-blue-800' : 'text-slate-700'}`}>
                        {source.name}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono truncate">{source.url}</span>
                    </div>
                    {activeSourceId === source.id && (
                        <div className="h-2 w-2 rounded-full bg-blue-500 shadow-[0_0_5px_rgba(59,130,246,0.5)]"></div>
                    )}
                </button>
                ))}
            </div>
            </div>

            {/* Filters */}
            <div className="bg-white border border-slate-200 rounded-xl p-5">
            <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-orange-500" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L12 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clipRule="evenodd" />
                </svg>
                内容关键词过滤 (自动匹配)
            </h3>
            <div className="flex flex-wrap gap-2">
                {keywords.map((k) => (
                    <span key={k} className="px-3 py-1.5 bg-orange-50 text-orange-700 border border-orange-100 rounded-lg text-sm font-medium flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-orange-400"></span>
                        {k}
                    </span>
                ))}
                <div className="px-3 py-1.5 bg-slate-50 text-slate-400 border border-slate-100 border-dashed rounded-lg text-sm flex items-center gap-1">
                    + 自定义
                </div>
            </div>
            
            <div className="mt-6 pt-4 border-t border-slate-100">
               <div className="flex items-center justify-between">
                 <span className="text-sm font-medium text-slate-700">启用持续学习 (Continuous Learning)</span>
                 <button 
                   onClick={() => !isCollecting && setIsContinuous(!isContinuous)}
                   className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${isContinuous ? 'bg-blue-600' : 'bg-slate-200'}`}
                 >
                   <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isContinuous ? 'translate-x-6' : 'translate-x-1'}`} />
                 </button>
               </div>
               <p className="text-xs text-slate-400 mt-1">
                 开启后，系统将每24小时自动扫描更新，并自动录入符合上述关键词的新法规。
               </p>
            </div>
            </div>
        </div>

        {/* Action Area */}
        <div className="flex items-center gap-4 pt-2">
          <button
            onClick={startCollection}
            disabled={isCollecting}
            className={`px-8 py-3 rounded-xl font-medium text-white shadow-lg transition-all flex items-center gap-2 ${
              isCollecting 
                ? 'bg-slate-400 cursor-not-allowed' 
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transform hover:-translate-y-0.5'
            }`}
          >
            {isCollecting ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {isContinuous ? '正在执行持续监测...' : '智能采集中...'}
              </>
            ) : (
              <>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" />
                </svg>
                {isContinuous ? '启动监测服务' : '开始任务'}
              </>
            )}
          </button>
          
          {isCollecting && (
            <div className="flex-1 max-w-md">
              <div className="flex justify-between text-xs text-slate-500 mb-1">
                <span className="font-mono">TASK_ID: {activeSourceId.toUpperCase()}_{Date.now().toString().slice(-4)}</span>
                <span className="font-mono">{progress}%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                <div 
                  className="bg-blue-600 h-full rounded-full transition-all duration-300 relative" 
                  style={{ width: `${progress}%` }}
                >
                    <div className="absolute top-0 left-0 bottom-0 right-0 bg-white/20 animate-pulse"></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Terminal / Logs */}
        <div className="bg-slate-900 rounded-xl overflow-hidden shadow-lg border border-slate-700 font-mono text-sm">
          <div className="bg-slate-800 px-4 py-2 flex items-center gap-2 border-b border-slate-700">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="ml-2 text-slate-400 text-xs">采集任务终端 - root@legal-crawler:~</span>
          </div>
          <div className="p-4 h-48 overflow-y-auto text-green-400 space-y-1">
             {logs.length === 0 ? (
               <span className="text-slate-500 opacity-50">等待指令...</span>
             ) : (
               logs.map((log, i) => (
                 <div key={i} className="break-all border-l-2 border-transparent hover:border-slate-700 pl-1">{log}</div>
               ))
             )}
             <div ref={logsEndRef} />
          </div>
        </div>

        {/* Results */}
        {collectedDocs.length > 0 && (
          <div className="animate-fade-in-up">
            <h3 className="font-semibold text-slate-800 mb-3">本次任务采集结果</h3>
            <div className="grid gap-3">
              {collectedDocs.map(doc => (
                 <div key={doc.id} className="bg-green-50 border border-green-200 p-4 rounded-xl flex justify-between items-center shadow-sm">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-bold bg-green-200 text-green-800 px-2 py-0.5 rounded uppercase tracking-wider">NEW</span>
                        <span className="font-bold text-slate-800">{doc.title}</span>
                      </div>
                      <p className="text-xs text-slate-500">
                          来源: {sources.find(s => s.id === activeSourceId)?.name} • 
                          匹配词: {keywords.filter(k => doc.content.includes(k) || doc.title.includes(k)).join(', ') || '安全生产'}
                      </p>
                    </div>
                    <div className="h-10 w-10 bg-white rounded-full flex items-center justify-center text-green-600 shadow-sm border border-green-100">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                 </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DataCollection;