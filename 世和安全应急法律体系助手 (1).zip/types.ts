export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  isError?: boolean;
}

export interface LawDocument {
  id: string;
  title: string;
  category: 'law' | 'regulation' | 'rule' | 'local';
  content: string;
  dateAdded: number;
}

export enum AppView {
  CHAT = 'CHAT',
  KNOWLEDGE_BASE = 'KNOWLEDGE_BASE',
  BUILD_STEPS = 'BUILD_STEPS',
  DATA_COLLECTION = 'DATA_COLLECTION',
  COMPLIANCE_CHECK = 'COMPLIANCE_CHECK',
  PUBLISH_GUIDE = 'PUBLISH_GUIDE',
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
}