import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import ChatArea from './components/ChatArea';
import KnowledgeBase from './components/KnowledgeBase';
import BuildSteps from './components/BuildSteps';
import DataCollection from './components/DataCollection';
import ComplianceCheck from './components/ComplianceCheck';
import PublishGuide from './components/PublishGuide';
import { AppView, LawDocument } from './types';

// Initial seed data simulating the "Full Learning" phase
// Includes major effective laws as of late 2023/2024 context
const INITIAL_DOCS: LawDocument[] = [
  {
    id: 'law-1',
    title: '中华人民共和国安全生产法（2021修正）',
    category: 'law',
    dateAdded: Date.now(),
    content: '【效力级别】法律\n【核心内容】\n第三条 安全生产工作坚持中国共产党的领导。安全生产工作应当以人为本，坚持人民至上、生命至上... 坚持安全第一、预防为主、综合治理的方针。\n第四条 生产经营单位必须遵守本法和其他有关安全生产的法律、法规，加强安全生产管理，建立健全全员安全生产责任制...\n第五条 生产经营单位的主要负责人是本单位安全生产第一责任人... 其他负责人对职责范围内的安全生产工作负责。\n第二十一条 生产经营单位的主要负责人对本单位安全生产工作负有下列职责：(一)建立健全并落实本单位全员安全生产责任制，加强安全生产标准化建设；(二)组织制定并实施本单位安全生产规章制度和操作规程；(三)组织制定并实施本单位安全生产教育和培训计划；(四)保证本单位安全生产投入的有效实施；(五)组织建立并落实安全风险分级管控和隐患排查治理双重预防工作机制，督促、检查本单位的安全生产工作，及时消除生产安全事故隐患；(六)组织制定并实施本单位的生产安全事故应急救援预案；(七)及时、如实报告生产安全事故。'
  },
  {
    id: 'law-2',
    title: '中华人民共和国突发事件应对法（2024修订）',
    category: 'law',
    dateAdded: Date.now(),
    content: '【效力级别】法律\n【核心内容】\n第三条 本法所称突发事件，是指突然发生，造成或者可能造成严重社会危害，需要采取应急处置措施予以应对的自然灾害、事故灾难、公共卫生事件和社会安全事件。\n第十一条 有关人民政府及其部门采取的应对突发事件的措施，应当与突发事件可能造成的社会危害的性质、程度和范围相适应；有多种措施可供选择的，应当选择有利于最大程度地保护公民、法人和其他组织权益的措施。\n第二十三条 矿山、建筑施工单位和易燃易爆物品、危险化学品、放射性物品等危险物品的生产、经营、储运、使用单位，应当制定具体应急预案，并对生产经营场所、有危险物品的建筑物、构筑物及周边环境开展隐患排查，及时采取措施消除隐患，防止发生突发事件。'
  },
  {
    id: 'law-3',
    title: '中华人民共和国消防法（2021修正）',
    category: 'law',
    dateAdded: Date.now(),
    content: '【效力级别】法律\n【核心内容】\n第十六条 机关、团体、企业、事业等单位应当履行下列消防安全职责：(一)落实消防安全责任制... (二)按照国家标准、行业标准配置消防设施、器材... (三)对建筑消防设施每年至少进行一次全面检测... (四)保障疏散通道、安全出口、消防车通道畅通... (五)组织防火检查... (六)组织进行有针对性的消防演练。\n第十七条 消防安全重点单位除应当履行本法第十六条规定的职责外，还应当履行下列消防安全职责：(一)确定消防安全管理人，组织实施本单位的消防安全管理工作；(二)建立消防档案，确定消防安全重点部位... (三)实行每日防火巡查，并建立巡查记录；(四)对职工进行岗前消防安全培训，定期组织消防安全培训和消防演练。'
  },
  {
    id: 'reg-1',
    title: '生产安全事故应急条例（2019）',
    category: 'regulation',
    dateAdded: Date.now(),
    content: '【效力级别】行政法规\n【核心内容】\n第八条 县级以上地方人民政府以及县级以上人民政府负有安全生产监督管理职责的部门，乡、镇人民政府以及街道办事处等地方人民政府派出机关，应当至少每2年组织1次生产安全事故应急救援预案演练。\n易燃易爆物品、危险化学品等危险物品的生产、经营、储存、运输单位，矿山、金属冶炼、城市轨道交通运营、建筑施工单位，以及宾馆、商场、娱乐场所、旅游景区等人员密集场所经营单位，应当至少每半年组织1次生产安全事故应急救援预案演练，并将演练情况报送所在地县级以上地方人民政府负有安全生产监督管理职责的部门。\n第十五条 生产经营单位应当对从业人员进行应急教育和培训，保证从业人员具备必要的应急知识，掌握风险防范技能和事故应急措施。'
  },
  {
    id: 'reg-2',
    title: '危险化学品安全管理条例',
    category: 'regulation',
    dateAdded: Date.now(),
    content: '【效力级别】行政法规\n【核心内容】\n第四条 危险化学品安全管理，应当坚持安全第一、预防为主、综合治理的方针，强化和落实企业的主体责任。\n第十四条 危险化学品生产企业进行生产前，应当依照《安全生产许可证条例》的规定，取得安全生产许可证。\n第二十条 生产、储存危险化学品的单位，应当根据其生产、储存的危险化学品的种类和危险特性，在作业场所设置相应的监测、监控、通风、防晒、调温、防火、灭火、防爆、泄压、防毒、中和、防潮、防雷、防静电、防腐、防渗漏、防护围堤或者隔离操作等安全设施、设备，并按照国家标准、行业标准或者国家有关规定对安全设施、设备进行经常性维护、保养，保证安全设施、设备正常使用。'
  },
  {
    id: 'reg-3',
    title: '生产安全事故报告和调查处理条例',
    category: 'regulation',
    dateAdded: Date.now(),
    content: '【效力级别】行政法规\n【核心内容】\n第三条 事故等级划分：\n（一）特别重大事故：30人以上死亡，或100人以上重伤，或1亿元以上直接经济损失；\n（二）重大事故：10-30人死亡，或50-100人重伤，或5000万-1亿元直接经济损失；\n（三）较大事故：3-10人死亡，或10-50人重伤，或1000万-5000万元直接经济损失；\n（四）一般事故：3人以下死亡，或10人以下重伤，或1000万元以下直接经济损失。\n第九条 事故发生后，事故现场有关人员应当立即向本单位负责人报告；单位负责人接到报告后，应当于1小时内向事故发生地县级以上人民政府安全生产监督管理部门和负有安全生产监督管理职责的部门报告。'
  },
  {
    id: 'rule-1',
    title: '生产安全事故应急预案管理办法',
    category: 'rule',
    dateAdded: Date.now(),
    content: '【效力级别】部门规章\n【核心内容】\n第六条 生产经营单位应急预案分为综合应急预案、专项应急预案和现场处置方案。\n综合应急预案，是指生产经营单位为应对各种生产安全事故而制定的综合性工作方案，是本单位应对生产安全事故的总体工作程序、措施和应急预案体系的总纲。\n专项应急预案，是指生产经营单位为应对某一种或者多种类型生产安全事故，或者针对重要生产设施、重大危险源、重大活动防止生产安全事故而制定的专项性工作方案。\n现场处置方案，是指生产经营单位根据不同生产安全事故类型，针对具体场所、装置或者设施所制定的应急处置措施。\n第十九条 生产经营单位应当在应急预案公布之日起20个工作日内，按照分级属地原则，向县级以上人民政府应急管理部门和其他负有安全生产监督管理职责的部门进行备案。'
  },
  {
    id: 'rule-2',
    title: '工贸企业有限空间作业安全管理与监督暂行规定',
    category: 'rule',
    dateAdded: Date.now(),
    content: '【效力级别】部门规章\n【核心内容】\n第八条 工贸企业实施有限空间作业前，应当对作业环境进行评估，分析存在的危险有害因素，提出消除、控制危害的措施，制定有限空间作业方案，并经本单位安全生产管理人员审核，负责人批准。\n第十二条 专项安全培训应当包括：有限空间作业的危险有害因素和安全防范措施；安全操作规程；检测仪器、劳动防护用品的正确使用；紧急情况下的应急处置措施。\n第十九条 工贸企业有限空间作业还应当符合下列要求：(一)保持有限空间出入口畅通；(二)设置明显的安全警示标志和警示说明；(三)作业前清点作业人员和工器具；(四)作业人员与外部有可靠的通讯联络；(五)监护人员不得离开作业现场，并与作业人员保持联系。'
  },
  {
    id: 'rule-3',
    title: '建设项目安全设施“三同时”监督管理办法',
    category: 'rule',
    dateAdded: Date.now(),
    content: '【效力级别】部门规章\n【核心内容】\n第三条 本办法所称建设项目安全设施“三同时”，是指生产经营单位在中华人民共和国领域内建设、改建、扩建工程项目（以下统称建设项目）的安全设施，必须与主体工程同时设计、同时施工、同时投入生产和使用。\n第四条 生产经营单位是建设项目安全设施建设的责任主体。建设项目安全设施必须符合国家有关法律、法规、规章和国家标准、行业标准、技术规范的规定。'
  },
  {
    id: 'rule-4',
    title: '工贸企业粉尘防爆安全规定',
    category: 'rule',
    dateAdded: Date.now(),
    content: '【效力级别】部门规章\n【核心内容】\n第四条 粉尘涉爆企业应当结合企业实际情况，建立健全粉尘防爆安全管理制度和岗位安全操作规程。\n第七条 粉尘涉爆企业应当辨识粉尘云、粉尘层爆炸安全风险，确定风险等级，建立风险分级管控清单，并制定落实针对性管控措施。\n第十条 粉尘涉爆企业应当在粉尘爆炸危险场所设置明显的安全警示标志，并在粉尘爆炸危险场所出入口、生产区域明显位置设置粉尘防爆安全风险告知牌。'
  },
  {
    id: 'rule-5',
    title: '危险化学品企业特殊作业安全规范 (GB 30871-2022)',
    category: 'rule',
    dateAdded: Date.now(),
    content: '【效力级别】国家标准（强制性）\n【核心内容】\n4.1 危险化学品企业应当建立健全特殊作业安全管理制度。\n5.1 动火作业前，应清除动火点附近的易燃易爆物。动火点周围15m范围内不应排放易燃气体。\n6.1 受限空间作业前，应当对受限空间进行清洗、置换、通风，并进行气体检测。检测结果合格后方可进入。'
  },
  {
    id: 'local-1',
    title: '广东省安全生产条例（2023修订）',
    category: 'local',
    dateAdded: Date.now(),
    content: '【效力级别】地方性法规\n【核心内容】\n第十一条 生产经营单位的主要负责人是本单位安全生产第一责任人... 应当明确各岗位的责任人员、责任范围和考核标准等内容。\n第二十二条 生产经营单位应当建立健全生产安全事故隐患排查治理制度... 对排查出的事故隐患，应当进行登记，明确责任人、处理措施和整改期限。\n第三十五条 在高危行业领域和重点单位，推行安全生产责任保险制度。鼓励其他生产经营单位投保安全生产责任保险。'
  },
  {
    id: 'local-2',
    title: '深圳经济特区安全生产条例',
    category: 'local',
    dateAdded: Date.now(),
    content: '【效力级别】地方性法规\n【核心内容】\n第十条 生产经营单位应当建立健全全员安全生产责任制，明确主要负责人、其他负责人、职能部门负责人、生产车间（区队）负责人、班组长以及其他从业人员的安全生产责任。\n第二十五条 生产经营单位应当建立健全安全风险分级管控制度，按照国家标准、行业标准和地方标准规范开展安全风险辨识、评估和分级，落实分级管控措施。'
  }
];

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.CHAT);
  const [documents, setDocuments] = useState<LawDocument[]>(INITIAL_DOCS);

  const handleAddDocument = (doc: LawDocument) => {
    setDocuments(prev => [doc, ...prev]);
  };

  const handleDeleteDocument = (id: string) => {
    setDocuments(prev => prev.filter(d => d.id !== id));
  };

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar 
        currentView={currentView} 
        onChangeView={setCurrentView} 
        docCount={documents.length}
      />
      
      <main className="flex-1 p-4 h-full overflow-hidden">
        {currentView === AppView.CHAT && (
          <ChatArea documents={documents} />
        )}
        
        {currentView === AppView.KNOWLEDGE_BASE && (
          <KnowledgeBase 
            documents={documents} 
            onAddDocument={handleAddDocument}
            onDeleteDocument={handleDeleteDocument}
          />
        )}
        
        {currentView === AppView.DATA_COLLECTION && (
          <DataCollection onAddDocument={handleAddDocument} />
        )}

        {currentView === AppView.COMPLIANCE_CHECK && (
          <ComplianceCheck />
        )}

        {currentView === AppView.PUBLISH_GUIDE && (
          <PublishGuide />
        )}

        {currentView === AppView.BUILD_STEPS && (
          <BuildSteps />
        )}
      </main>
    </div>
  );
};

export default App;