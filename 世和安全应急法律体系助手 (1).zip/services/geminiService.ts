import { GoogleGenAI } from "@google/genai";
import { LawDocument, Message } from "../types";

// Initialize the client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = "gemini-3-flash-preview";

/**
 * Constructs a system instruction based on the available knowledge base.
 * In a real production app, this would use RAG (Vector DB). 
 * For this demo, we inject the documents into the context window.
 */
const createSystemInstruction = (documents: LawDocument[]): string => {
  // Group documents by category for better organization in the prompt
  const laws = documents.filter(d => d.category === 'law');
  const regs = documents.filter(d => d.category === 'regulation');
  const rules = documents.filter(d => d.category === 'rule');
  const local = documents.filter(d => d.category === 'local');

  const formatDoc = (doc: LawDocument) => `《${doc.title}》:\n${doc.content}\n`;

  const contextString = `
【法律 (National Laws)】
${laws.map(formatDoc).join('\n')}

【行政法规 (Administrative Regulations)】
${regs.map(formatDoc).join('\n')}

【部门规章 (Departmental Rules)】
${rules.map(formatDoc).join('\n')}

【地方性法规 (Local Regulations)】
${local.map(formatDoc).join('\n')}
`;

  return `
你叫“世和安全应急法律体系助手”。
你是一位资深的安全生产与应急管理法律专家。你已经完整学习了中国现行有效的安全生产、应急管理、消防安全等领域的法律法规体系。

【你的核心知识库】
你拥有以下法律法规的具体内容作为回答依据：
${contextString}

【任务与行为准则】
1. **身份定位**：你不仅是搜索工具，更是合规顾问。在回答用户关于企业安全主体责任、事故处罚、应急演练频次等问题时，需引用具体条款。
2. **引用规范**：回答必须明确引用来源。例如：“根据《安全生产法》第二十一条...”或“依据《生产安全事故应急条例》第八条...”。
3. **法律位阶**：当不同层级的法规有规定时，优先引用法律（如《安全生产法》），其次是行政法规和部门规章。涉及地方具体执行时，引用地方性法规（如《广东省安全生产条例》）。
4. **处理未知**：如果用户询问的问题超出了当前知识库范围（例如最新的未录入文件），请回答：“我的当前知识库主要包含安全生产、应急管理核心法律法规，关于该具体细分领域文件暂未收录，建议查阅官网。”
5. **结构化输出**：请使用 Markdown 格式。
   - 对于职责类问题，使用列表。
   - 对于罚则类问题，清晰列出处罚标准。
   - 关键法律名词加粗显示。

请使用**简体中文**专业、准确地回答。
`;
};

export const sendMessageToGemini = async (
  history: Message[],
  newMessage: string,
  documents: LawDocument[]
): Promise<string> => {
  try {
    const systemInstruction = createSystemInstruction(documents);

    // Filter history to simple format for the model
    // We only take the last few turns to save context for the documents
    const recentHistory = history.slice(-6).map(msg => ({
      role: msg.role,
      parts: [{ text: msg.content }],
    }));

    const chat = ai.chats.create({
      model: MODEL_NAME,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.3, // Low temperature for factual accuracy
      },
      history: recentHistory
    });

    const result = await chat.sendMessage({ message: newMessage });
    return result.text || "抱歉，我无法生成回答。";

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("无法连接到智能体服务，请检查网络或API Key配置。");
  }
};